const User = require('../models/User');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

exports.register = async (req, res) => {
  try {
    const { username, email, password, role } = req.body;
    const user = await User.create({ username, email, password, role });
    
    res.status(201).json({ message: "User successfully registered", userId: user._id });
  } catch (error) {
    console.error(error); // Log the full error object for more details
    res.status(500).json({ error: "An error occurred during user registration." });
  }
};

// Function to get all users
exports.getAllUsers = async (req, res) => {
  const { page = 1, limit = 10 } = req.query; // Default to page 1, limit 10
  try {
    const users = await User.find({})
                            .limit(limit * 1)
                            .skip((page - 1) * limit);
    const count = await User.countDocuments();
    res.json({
      users,
      totalPages: Math.ceil(count / limit),
      currentPage: page,
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "An error occurred while fetching users." });
  }
};